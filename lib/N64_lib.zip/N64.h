class N64 {
  public:
    N64(int pin);
    void begin(int baud);
    void read();
};

